import 'package:flutter/material.dart';
import 'screens/game_home_screen.dart';

void main() {
  runApp(const ApexEchoesApp());
}

class ApexEchoesApp extends StatelessWidget {
  const ApexEchoesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Apex Echoes',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF9800),
          secondary: Color(0xFF9C27B0),
          surface: Color(0xFF1E1E1E),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: const Color(0xFF1A1A1A),
          indicatorColor: Colors.orangeAccent.withOpacity(0.3),
        ),
      ),
      home: const GameHomeScreen(),
    );
  }
}
