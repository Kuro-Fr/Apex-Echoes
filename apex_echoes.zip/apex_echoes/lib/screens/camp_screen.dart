import 'package:flutter/material.dart';
import '../models/player_model.dart';
import '../models/companion_model.dart';

/// Écran de campement regroupant Sanctuaire (repos), Marchand, Forgeron et
/// la gestion des expéditions en arrière-plan (AFK) du compagnon.
class CampScreen extends StatefulWidget {
  final Player player;
  final CompanionPet? companion;
  final VoidCallback onChanged;
  final void Function(String message) showMessage;

  const CampScreen({
    super.key,
    required this.player,
    required this.companion,
    required this.onChanged,
    required this.showMessage,
  });

  @override
  State<CampScreen> createState() => _CampScreenState();
}

class _CampScreenState extends State<CampScreen> {
  bool _spend(int cost) {
    if (widget.player.orins < cost) {
      widget.showMessage("Pas assez d'Orins (il en faut $cost).");
      return false;
    }
    widget.player.orins -= cost;
    return true;
  }

  void _rest() {
    setState(() {
      widget.player.hp = widget.player.maxHp;
      widget.player.stamina = widget.player.maxStamina;
      widget.onChanged();
    });
    widget.showMessage("Vous vous reposez au Sanctuaire. PV et Endurance restaurés.");
  }

  void _buyPotion() {
    if (!_spend(20)) return;
    setState(() {
      widget.player.hp = (widget.player.hp + 50).clamp(0, widget.player.maxHp);
      widget.onChanged();
    });
    widget.showMessage("Potion utilisée : +50 PV.");
  }

  void _buyStaminaRation() {
    if (!_spend(15)) return;
    setState(() {
      widget.player.stamina = (widget.player.stamina + 30).clamp(0, widget.player.maxStamina);
      widget.onChanged();
    });
    widget.showMessage("Ration consommée : +30 Endurance.");
  }

  void _buyWhetstone() {
    final weapon = widget.player.weapon;
    if (weapon == null) {
      widget.showMessage("Vous n'avez aucune arme équipée.");
      return;
    }
    if (!_spend(10)) return;
    setState(() {
      weapon.currentSharpness = weapon.sharpnessMax;
      widget.onChanged();
    });
    widget.showMessage("Pierre à aiguiser utilisée : tranchant restauré.");
  }

  void _feedCompanionRation() {
    if (widget.companion == null) {
      widget.showMessage("Vous n'avez pas de compagnon à nourrir.");
      return;
    }
    if (!_spend(15)) return;
    setState(() {
      widget.companion!.feed();
      widget.onChanged();
    });
    widget.showMessage("Votre compagnon savoure sa ration !");
  }

  void _forgeUpgrade() {
    final weapon = widget.player.weapon;
    if (weapon == null) {
      widget.showMessage("Équipez une arme avant de la faire forger.");
      return;
    }
    final cost = 20 + weapon.attackBonus * 8;
    if (!_spend(cost)) return;
    setState(() {
      weapon.attackBonus += 2;
      weapon.defenseBonus += 1;
      widget.onChanged();
    });
    widget.showMessage("Le Forgeron améliore votre arme (+2 ATQ / +1 DEF) pour $cost Orins.");
  }

  void _startExpedition(int hours) {
    setState(() {
      widget.companion!.startExpedition(hours);
      widget.onChanged();
    });
    widget.showMessage("Votre compagnon part en expédition pour $hours h.");
  }

  void _collectExpedition() {
    setState(() {
      final reward = widget.companion!.collectExpeditionReward();
      widget.player.orins += reward;
      widget.onChanged();
    });
    widget.showMessage("Votre compagnon revient d'expédition avec des Orins !");
  }

  @override
  Widget build(BuildContext context) {
    final weapon = widget.player.weapon;
    final companion = widget.companion;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle("🏕️ Sanctuaire"),
        _actionCard(
          title: "Se reposer",
          subtitle: "Restaure entièrement vos PV et votre Endurance. Gratuit.",
          buttonLabel: "Se reposer",
          onPressed: _rest,
        ),
        const SizedBox(height: 20),
        _sectionTitle("🛒 Marchand"),
        _actionCard(
          title: "Potion de Soin",
          subtitle: "+50 PV",
          buttonLabel: "20 Orins",
          onPressed: _buyPotion,
        ),
        _actionCard(
          title: "Ration d'Endurance",
          subtitle: "+30 Endurance",
          buttonLabel: "15 Orins",
          onPressed: _buyStaminaRation,
        ),
        _actionCard(
          title: "Pierre à Aiguiser",
          subtitle: "Restaure le tranchant de l'arme équipée",
          buttonLabel: "10 Orins",
          onPressed: _buyWhetstone,
        ),
        _actionCard(
          title: "Ration pour Compagnon",
          subtitle: companion == null ? "Nécessite un compagnon" : "Nourrit votre compagnon",
          buttonLabel: "15 Orins",
          onPressed: _feedCompanionRation,
        ),
        const SizedBox(height: 20),
        _sectionTitle("⚒️ Forgeron"),
        _actionCard(
          title: weapon == null ? "Aucune arme équipée" : "Améliorer : ${weapon.name}",
          subtitle: weapon == null
              ? "Équipez une arme dans l'Inventaire"
              : "+2 ATQ / +1 DEF (coût croissant)",
          buttonLabel: weapon == null ? "—" : "${20 + weapon.attackBonus * 8} Orins",
          onPressed: weapon == null ? null : _forgeUpgrade,
        ),
        const SizedBox(height: 20),
        _sectionTitle("🗺️ Expédition du Compagnon (AFK)"),
        if (companion == null)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text("Vous n'avez pas encore de compagnon.", style: TextStyle(color: Colors.white70)),
          )
        else if (companion.isOnExpedition)
          Card(
            color: const Color(0xFF1E1E1E),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("${companion.speciesName} explore en votre absence...",
                      style: const TextStyle(color: Colors.purpleAccent)),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: companion.expeditionProgress.clamp(0.0, 1.0),
                    color: Colors.purpleAccent,
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: companion.isExpeditionReady ? _collectExpedition : null,
                    child: Text(companion.isExpeditionReady
                        ? "Récupérer le butin"
                        : "Expédition en cours..."),
                  ),
                ],
              ),
            ),
          )
        else
          Wrap(
            spacing: 8,
            children: [1, 4, 8].map((h) {
              return ElevatedButton(
                onPressed: () => _startExpedition(h),
                child: Text("Envoyer $h h"),
              );
            }).toList(),
          ),
      ],
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      );

  Widget _actionCard({
    required String title,
    required String subtitle,
    required String buttonLabel,
    required VoidCallback? onPressed,
  }) {
    return Card(
      color: const Color(0xFF1E1E1E),
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        title: Text(title),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        trailing: ElevatedButton(onPressed: onPressed, child: Text(buttonLabel)),
      ),
    );
  }
}
