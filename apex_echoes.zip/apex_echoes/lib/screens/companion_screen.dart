import 'package:flutter/material.dart';
import '../models/companion_model.dart';

class CompanionScreen extends StatefulWidget {
  final CompanionPet? companion;
  final VoidCallback onChanged;

  const CompanionScreen({super.key, required this.companion, required this.onChanged});

  @override
  State<CompanionScreen> createState() => _CompanionScreenState();
}

class _CompanionScreenState extends State<CompanionScreen> {
  @override
  Widget build(BuildContext context) {
    final companion = widget.companion;

    if (companion == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            "Vous n'avez pas encore d'œuf. Vainquez un Grand Boss (Apex) "
            "pour avoir une chance d'en récupérer un !",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70, fontSize: 15),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            companion.speciesName,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.purpleAccent),
          ),
          Text("Stade : ${companion.currentStage.label}", style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 16),
          _statBar("🍖 Faim", companion.hungerLevel, Colors.orangeAccent),
          _statBar("🛁 Hygiène", companion.hygieneLevel, Colors.lightBlueAccent),
          _statBar("💜 Affection", companion.affectionLevel, Colors.pinkAccent),
          const SizedBox(height: 12),
          Text("Croissance : ${(companion.growthProgress * 100).toStringAsFixed(0)}%",
              style: const TextStyle(color: Colors.greenAccent)),
          LinearProgressIndicator(value: companion.growthProgress, color: Colors.greenAccent),
          const SizedBox(height: 20),
          Text(
            "Bonus passifs (3ᵉ Atout) : +${companion.bonusPassiveAttack} ATQ / "
            "+${companion.bonusPassiveDefense} DEF",
            style: const TextStyle(color: Colors.amber),
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton.icon(
                onPressed: () => setState(() {
                  companion.feed();
                  widget.onChanged();
                }),
                icon: const Text("🍖"),
                label: const Text("Nourrir"),
              ),
              ElevatedButton.icon(
                onPressed: () => setState(() {
                  companion.bathe();
                  widget.onChanged();
                }),
                icon: const Text("🛁"),
                label: const Text("Baigner"),
              ),
              ElevatedButton.icon(
                onPressed: () => setState(() {
                  companion.train();
                  widget.onChanged();
                }),
                icon: const Text("🏋️"),
                label: const Text("Entraîner"),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statBar(String label, int value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 13)),
          LinearProgressIndicator(value: value / 100, color: color, backgroundColor: Colors.black45),
        ],
      ),
    );
  }
}
