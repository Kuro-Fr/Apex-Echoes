import 'package:flutter/material.dart';
import '../models/player_model.dart';
import '../models/equipment_model.dart';

class InventoryScreen extends StatefulWidget {
  final Player player;
  final List<Equipment> inventory;
  final VoidCallback onChanged;

  const InventoryScreen({
    super.key,
    required this.player,
    required this.inventory,
    required this.onChanged,
  });

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  Color _rarityColor(Rarity rarity) {
    switch (rarity) {
      case Rarity.common:
        return Colors.grey;
      case Rarity.rare:
        return Colors.lightBlueAccent;
      case Rarity.epic:
        return Colors.purpleAccent;
      case Rarity.legendary:
        return Colors.orangeAccent;
      case Rarity.mythic:
        return Colors.redAccent;
      case Rarity.cursed:
        return Colors.deepPurple;
    }
  }

  void _equip(Equipment item) {
    setState(() {
      widget.player.equippedItems[item.slot] = item;
      widget.onChanged();
    });
  }

  void _sell(Equipment item) {
    setState(() {
      final value = 10 + (item.attackBonus + item.defenseBonus) * 2;
      widget.player.orins += value;
      widget.inventory.remove(item);
      widget.onChanged();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.inventory.isEmpty) {
      return const Center(
        child: Text("Votre inventaire est vide. Partez chasser pour looter du matériel !",
            style: TextStyle(color: Colors.white70)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: widget.inventory.length,
      itemBuilder: (context, index) {
        final item = widget.inventory[index];
        final equipped = widget.player.equippedItems[item.slot] == item;

        return Card(
          color: const Color(0xFF1E1E1E),
          margin: const EdgeInsets.symmetric(vertical: 4),
          child: ListTile(
            title: Text(item.name, style: TextStyle(color: _rarityColor(item.rarity))),
            subtitle: Text(
              "${item.slot.label} · ${item.rarity.label} · ATQ +${item.attackBonus} / DEF +${item.defenseBonus}",
              style: const TextStyle(color: Colors.white60, fontSize: 12),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!equipped)
                  IconButton(
                    icon: const Icon(Icons.check_circle_outline, color: Colors.greenAccent),
                    onPressed: () => _equip(item),
                    tooltip: 'Équiper',
                  )
                else
                  const Icon(Icons.check_circle, color: Colors.green),
                IconButton(
                  icon: const Icon(Icons.sell_outlined, color: Colors.amber),
                  onPressed: () => _sell(item),
                  tooltip: 'Vendre',
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
