import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models/player_model.dart';
import '../models/equipment_model.dart';
import '../models/zone_model.dart';
import '../models/monster_model.dart';
import '../models/companion_model.dart';
import '../models/bestiary_model.dart';
import '../engine/zone_generator.dart';
import '../engine/monster_generator.dart';
import '../engine/equipment_generator.dart';
import '../core/database/save_service.dart';
import 'combat_screen.dart';
import 'companion_screen.dart';
import 'inventory_screen.dart';
import 'camp_screen.dart';
import 'codex_screen.dart';

class GameHomeScreen extends StatefulWidget {
  const GameHomeScreen({super.key});

  @override
  State<GameHomeScreen> createState() => _GameHomeScreenState();
}

class _GameHomeScreenState extends State<GameHomeScreen> {
  final Player _player = Player();
  final List<Equipment> _inventory = [];
  final Map<String, int> _bestiaryKillCounts = {};
  final Map<String, BestiaryEntry> _bestiary = {};
  CompanionPet? _companion;

  Timer? _autoSaveTimer;
  int _currentTab = 0;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadGame();
    _autoSaveTimer = Timer.periodic(const Duration(seconds: 1), (_) => _saveGame());
  }

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadGame() async {
    final data = await SaveService.loadGame();
    if (data != null) {
      setState(() {
        final loadedPlayer = Player.fromJson(data['player']);
        _player.hp = loadedPlayer.hp;
        _player.maxHp = loadedPlayer.maxHp;
        _player.stamina = loadedPlayer.stamina;
        _player.maxStamina = loadedPlayer.maxStamina;
        _player.baseAttack = loadedPlayer.baseAttack;
        _player.baseDefense = loadedPlayer.baseDefense;
        _player.orins = loadedPlayer.orins;
        _player.equippedItems = loadedPlayer.equippedItems;
        _companion = SaveService.companionFromSave(data['companion']);
        final rawKills = data['bestiaryKillCounts'] as Map<String, dynamic>? ?? {};
        _bestiaryKillCounts.addAll(rawKills.map((k, v) => MapEntry(k, v as int)));

        final rawBestiary = data['bestiaryEntries'] as Map<String, dynamic>? ?? {};
        _bestiary.addAll(
          rawBestiary.map((k, v) => MapEntry(k, BestiaryEntry.fromJson(v as Map<String, dynamic>))),
        );

        final rawInventory = data['inventory'] as List<dynamic>? ?? [];
        _inventory.addAll(
          rawInventory.map((e) => Equipment.fromJson(e as Map<String, dynamic>)),
        );

        // Ré-associe les objets équipés aux mêmes instances que celles de
        // l'inventaire (par id), pour que les comparaisons d'identité dans
        // l'écran d'inventaire (équipé/non équipé) restent cohérentes.
        for (final slot in EquipmentSlot.values) {
          final equipped = _player.equippedItems[slot];
          if (equipped == null) continue;
          final match = _inventory.where((e) => e.id == equipped.id);
          if (match.isNotEmpty) {
            _player.equippedItems[slot] = match.first;
          } else {
            _inventory.add(equipped);
          }
        }
      });
    }
    setState(() => _loaded = true);
  }

  Future<void> _saveGame() async {
    if (!_loaded) return;
    await SaveService.saveGame(
      player: _player,
      companion: _companion,
      bestiaryKillCounts: _bestiaryKillCounts,
      bestiaryEntries: _bestiary.map((k, v) => MapEntry(k, v.toJson())),
      inventory: _inventory.map((e) => e.toJson()).toList(),
    );
  }

  void _openZoneDialog(Zone zone) {
    final report = ZoneGenerator.generateReport(zone);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E1E),
        title: Text("Rapport d'expédition · ${zone.name}"),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Chance de croiser un monstre corrompu (Aura Violette) : "
                "${(report.corruptionChance * 100).toStringAsFixed(0)}%",
                style: const TextStyle(color: Colors.purpleAccent),
              ),
              const SizedBox(height: 8),
              const Text("Monstres recensés :", style: TextStyle(color: Colors.white70)),
              SizedBox(
                height: 200,
                child: ListView(
                  children: report.plannedSlots
                      .map((s) => Text(
                            "${s.isBoss ? '👑 ' : '• '}${s.monsterName}"
                            "${s.willBeCorrupted ? ' ⚠️' : ''}",
                            style: TextStyle(
                              color: s.isBoss ? Colors.orangeAccent : Colors.white60,
                            ),
                          ))
                      .toList(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Annuler"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _enterZone(zone, report);
            },
            child: const Text("Entrer dans la zone"),
          ),
        ],
      ),
    );
  }

  Future<void> _enterZone(Zone zone, ExpeditionReport report) async {
    final slot = report.plannedSlots[Random().nextInt(report.plannedSlots.length)];
    final monster = MonsterGenerator.generateFromSlot(slot: slot, zone: zone);

    final outcome = await Navigator.of(context).push<CombatOutcome>(
      MaterialPageRoute(
        builder: (_) => CombatScreen(player: _player, monster: monster, zone: zone),
      ),
    );

    if (outcome == null) return;

    if (outcome.victory) {
      setState(() {
        final rewardOrins = monster.stage == MonsterStage.apexBoss ? 120 : 35;
        _player.orins += rewardOrins;
        _bestiaryKillCounts[monster.name] = (_bestiaryKillCounts[monster.name] ?? 0) + 1;

        // Mise à jour de la fiche de bestiaire (Codex)
        final existingEntry = _bestiary[monster.name];
        if (existingEntry == null) {
          _bestiary[monster.name] = BestiaryEntry.fromMonster(monster);
        } else {
          existingEntry.timesDefeated++;
        }

        // Loot d'équipement
        final lootedSlot = EquipmentSlot.values[Random().nextInt(6)]; // hors petPerk
        final item = EquipmentGenerator.generate(slot: lootedSlot, element: zone.theme);
        _inventory.add(item);

        // Roll pour l'œuf du compagnon
        if (_companion == null && Random().nextDouble() < monster.eggDropRate) {
          _companion = CompanionPet(
            id: 'companion_${DateTime.now().millisecondsSinceEpoch}',
            speciesName: monster.name,
            originApexBossId: monster.id,
            hatchDate: DateTime.now(),
            growthDaysRequired: monster.stage == MonsterStage.apexBoss ? 15 : 8,
          );
        }
      });
      _showSnack("Victoire ! +${monster.stage == MonsterStage.apexBoss ? 120 : 35} Orins, butin récupéré.");
    } else {
      setState(() {
        _player.hp = _player.maxHp; // Retour au campement, on se soigne
        _player.stamina = _player.maxStamina;
      });
      _showSnack("Vous avez été vaincu... retour au campement.");
    }
    _saveGame();
  }

  void _showSnack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    final tabs = [
      _buildHuntTab(),
      CompanionScreen(companion: _companion, onChanged: () => setState(() {})),
      InventoryScreen(player: _player, inventory: _inventory, onChanged: () => setState(() {})),
      CampScreen(
        player: _player,
        companion: _companion,
        onChanged: () => setState(() {}),
        showMessage: _showSnack,
      ),
      CodexScreen(bestiary: _bestiary),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('APEX ECHOES', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: const Color(0xFF1A1A1A),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("❤️ PV: ${_player.hp}/${_player.maxHp}",
                        style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                    Text("⚡ Endurance: ${_player.stamina}/${_player.maxStamina}",
                        style: const TextStyle(color: Colors.greenAccent)),
                  ],
                ),
                Text("💰 ${_player.orins} Orins",
                    style: const TextStyle(color: Colors.orangeAccent, fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Expanded(child: tabs[_currentTab]),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentTab,
        onDestinationSelected: (i) => setState(() => _currentTab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.explore), label: 'Chasse'),
          NavigationDestination(icon: Icon(Icons.egg_alt), label: 'Compagnon'),
          NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Inventaire'),
          NavigationDestination(icon: Icon(Icons.local_fire_department), label: 'Camp'),
          NavigationDestination(icon: Icon(Icons.menu_book), label: 'Codex'),
        ],
      ),
    );
  }

  Widget _buildHuntTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: ZoneGenerator.availableZones.length,
      itemBuilder: (context, index) {
        final zone = ZoneGenerator.availableZones[index];
        return Card(
          color: const Color(0xFF1E1E1E),
          margin: const EdgeInsets.symmetric(vertical: 6),
          child: ListTile(
            title: Text(zone.name, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text("Thème : ${zone.theme.label} ${zone.theme.icon} · Danger : ${zone.dangerLevel}"),
            trailing: ElevatedButton(
              onPressed: () => _openZoneDialog(zone),
              child: const Text("TRAQUER"),
            ),
          ),
        );
      },
    );
  }
}
