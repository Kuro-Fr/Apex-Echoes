import 'package:flutter/material.dart';
import '../models/monster_model.dart';
import '../models/player_model.dart';
import '../models/zone_model.dart';
import '../models/combat_log.dart';
import '../engine/combat_engine.dart';

/// Résultat renvoyé à l'écran d'accueil quand le combat se termine.
class CombatOutcome {
  final bool victory;
  final Monster monster;

  CombatOutcome({required this.victory, required this.monster});
}

class CombatScreen extends StatefulWidget {
  final Player player;
  final Monster monster;
  final Zone zone;

  const CombatScreen({
    super.key,
    required this.player,
    required this.monster,
    required this.zone,
  });

  @override
  State<CombatScreen> createState() => _CombatScreenState();
}

class _CombatScreenState extends State<CombatScreen> {
  late final BattleSession _session;
  bool _combatOver = false;

  @override
  void initState() {
    super.initState();
    _session = BattleSession(monster: widget.monster, player: widget.player);
    _session.logs.add(CombatLog(
      "Un ${widget.monster.name} apparaît dans ${widget.zone.name} ! "
      "${widget.monster.isCorrupted ? '⚠️ AURA VIOLETTE (FRÉNÉSIE) !' : ''}",
      LogType.info,
    ));
  }

  void _handleAction(CombatActionResult Function() action) {
    if (_combatOver) return;
    setState(() {
      final result = action();
      if (result.monsterDefeated || result.playerDefeated) {
        _combatOver = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final player = widget.player;
    final monster = widget.monster;

    return Scaffold(
      appBar: AppBar(title: Text(widget.zone.name)),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: const Color(0xFF1A1A1A),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("❤️ PV: ${player.hp}/${player.maxHp}",
                        style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                    Text("⚡ Endurance: ${player.stamina}/${player.maxStamina}",
                        style: const TextStyle(color: Colors.greenAccent)),
                    if (player.weapon != null)
                      Text("🔪 Tranchant: ${player.weapon!.currentSharpness}/${player.weapon!.sharpnessMax}",
                          style: const TextStyle(color: Colors.amber)),
                  ],
                ),
                Text("💰 ${player.orins} Orins",
                    style: const TextStyle(color: Colors.orangeAccent, fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          const Divider(height: 1, color: Colors.white24),
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: monster.isCorrupted ? Colors.purple.withOpacity(0.2) : const Color(0xFF252525),
              border: Border.all(
                color: monster.isCorrupted ? Colors.purpleAccent : Colors.orangeAccent,
                width: 2,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Text(
                  "${monster.name} (${monster.stage.label})",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: monster.isCorrupted ? Colors.purpleAccent : Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: (monster.hp / monster.currentMaxHp).clamp(0.0, 1.0),
                  backgroundColor: Colors.black45,
                  color: monster.isCorrupted ? Colors.purpleAccent : Colors.redAccent,
                ),
                const SizedBox(height: 8),
                Text("PV : ${monster.hp.clamp(0, monster.currentMaxHp)} / ${monster.currentMaxHp}"),
              ],
            ),
          ),
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.white12),
              ),
              child: ListView.builder(
                reverse: true,
                itemCount: _session.logs.length,
                itemBuilder: (context, index) {
                  final log = _session.logs[_session.logs.length - 1 - index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Text(
                      log.message,
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 13, color: Colors.white70),
                    ),
                  );
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: _combatOver
                ? ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: monster.isDead ? Colors.green : Colors.grey,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      minimumSize: const Size.fromHeight(48),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop(
                        CombatOutcome(victory: monster.isDead, monster: monster),
                      );
                    },
                    child: Text(monster.isDead ? "CONTINUER (Victoire)" : "RETOUR AU CAMPEMENT"),
                  )
                : Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.redAccent,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          onPressed: () => _handleAction(_session.attack),
                          child: const Text("ATTAQUER", style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber.shade700,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        onPressed: () => _handleAction(_session.sharpenWeapon),
                        child: const Text("AIGUISER"),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueGrey,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        onPressed: () => _handleAction(_session.rest),
                        child: const Text("REPOS"),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}
