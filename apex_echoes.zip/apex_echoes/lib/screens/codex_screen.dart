import 'package:flutter/material.dart';
import '../models/bestiary_model.dart';
import '../models/element_type.dart';
import '../engine/lore_database.dart';

class CodexScreen extends StatelessWidget {
  final Map<String, BestiaryEntry> bestiary;

  const CodexScreen({super.key, required this.bestiary});

  int get _totalKills => bestiary.values.fold(0, (sum, e) => sum + e.timesDefeated);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          const TabBar(
            tabs: [
              Tab(text: 'Bestiaire'),
              Tab(text: 'Lore du Monde'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                _buildBestiaryTab(context),
                _buildWorldLoreTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBestiaryTab(BuildContext context) {
    if (bestiary.isEmpty) {
      return const Center(
        child: Text("Aucun monstre rencontré pour le moment. Partez chasser !",
            style: TextStyle(color: Colors.white70)),
      );
    }

    final entries = bestiary.values.toList()..sort((a, b) => a.name.compareTo(b.name));

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: entries.length,
      itemBuilder: (context, index) {
        final entry = entries[index];
        return Card(
          color: const Color(0xFF1E1E1E),
          margin: const EdgeInsets.symmetric(vertical: 4),
          child: ExpansionTile(
            title: Text(entry.name, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text("Vaincu ${entry.timesDefeated} fois", style: const TextStyle(color: Colors.white60)),
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Élément : ${entry.element.label} ${entry.element.icon}",
                        style: const TextStyle(color: Colors.white70)),
                    Text("Faiblesse : ${entry.weakness.label} ${entry.weakness.icon}",
                        style: const TextStyle(color: Colors.white70)),
                    Text("Taux de drop d'œuf : ${(entry.eggDropRate * 100).toStringAsFixed(1)}%",
                        style: const TextStyle(color: Colors.purpleAccent)),
                    const SizedBox(height: 12),
                    const Text("Lore débloqué :",
                        style: TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold)),
                    ...LoreDatabase.loreForMonster(entry.name).map((lore) {
                      final unlocked = entry.timesDefeated >= lore.unlockThreshold;
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: unlocked
                            ? Text("• ${lore.title}\n   ${lore.content}",
                                style: const TextStyle(color: Colors.white70, fontSize: 13))
                            : Text(
                                "• ??? (débloqué à ${lore.unlockThreshold} victoires)",
                                style: const TextStyle(color: Colors.white24, fontSize: 13),
                              ),
                      );
                    }),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildWorldLoreTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: LoreDatabase.worldLore.length,
      itemBuilder: (context, index) {
        final lore = LoreDatabase.worldLore[index];
        final unlocked = _totalKills >= lore.unlockThreshold;
        return Card(
          color: const Color(0xFF1E1E1E),
          margin: const EdgeInsets.symmetric(vertical: 4),
          child: ListTile(
            title: Text(
              unlocked ? lore.title : "??? Fragment scellé",
              style: TextStyle(color: unlocked ? Colors.orangeAccent : Colors.white24),
            ),
            subtitle: Text(
              unlocked
                  ? lore.content
                  : "Se débloque après ${lore.unlockThreshold} victoires cumulées "
                      "(actuellement $_totalKills).",
              style: TextStyle(color: unlocked ? Colors.white70 : Colors.white24),
            ),
          ),
        );
      },
    );
  }
}
