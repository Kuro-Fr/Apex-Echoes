import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../security/encryption_service.dart';
import '../../models/player_model.dart';
import '../../models/companion_model.dart';
import '../../models/monster_model.dart';

/// Gère la sauvegarde automatique (chaque seconde côté UI) de l'état complet
/// du jeu, sous forme chiffrée AES-256 sur le stockage local (100% hors-ligne).
class SaveService {
  static Future<File> _getSaveFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/apex_echoes_secure.save');
  }

  static Future<void> saveGame({
    required Player player,
    CompanionPet? companion,
    Map<String, int> bestiaryKillCounts = const {},
    Map<String, dynamic> bestiaryEntries = const {},
    List<Map<String, dynamic>> inventory = const [],
  }) async {
    final raw = jsonEncode({
      'player': player.toJson(),
      'inventory': inventory,
      'bestiaryEntries': bestiaryEntries,
      'companion': companion == null
          ? null
          : {
              'id': companion.id,
              'speciesName': companion.speciesName,
              'originApexBossId': companion.originApexBossId,
              'currentStage': companion.currentStage.index,
              'hungerLevel': companion.hungerLevel,
              'hygieneLevel': companion.hygieneLevel,
              'affectionLevel': companion.affectionLevel,
              'hatchDate': companion.hatchDate.toIso8601String(),
              'growthDaysRequired': companion.growthDaysRequired,
              'growthDaysAccumulated': companion.growthDaysAccumulated,
              'bonusPassiveAttack': companion.bonusPassiveAttack,
              'bonusPassiveDefense': companion.bonusPassiveDefense,
              'trainingLevel': companion.trainingLevel,
              'expeditionStart': companion.expeditionStart?.toIso8601String(),
              'expeditionDurationHours': companion.expeditionDurationHours,
            },
      'bestiaryKillCounts': bestiaryKillCounts,
    });

    final encrypted = await EncryptionService.encryptData(raw);
    final file = await _getSaveFile();
    await file.writeAsString(encrypted);
  }

  /// Retourne `null` si aucune sauvegarde n'existe ou si elle a été altérée.
  static Future<Map<String, dynamic>?> loadGame() async {
    try {
      final file = await _getSaveFile();
      if (!await file.exists()) return null;

      final encrypted = await file.readAsString();
      final decrypted = await EncryptionService.decryptData(encrypted);
      if (decrypted == null) return null;

      return jsonDecode(decrypted) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  static CompanionPet? companionFromSave(Map<String, dynamic>? raw) {
    if (raw == null) return null;
    return CompanionPet(
      id: raw['id'],
      speciesName: raw['speciesName'],
      originApexBossId: raw['originApexBossId'],
      currentStage: MonsterStage.values[raw['currentStage']],
      hungerLevel: raw['hungerLevel'],
      hygieneLevel: raw['hygieneLevel'],
      affectionLevel: raw['affectionLevel'],
      hatchDate: DateTime.parse(raw['hatchDate']),
      growthDaysRequired: raw['growthDaysRequired'],
      growthDaysAccumulated: (raw['growthDaysAccumulated'] as num).toDouble(),
      bonusPassiveAttack: raw['bonusPassiveAttack'],
      bonusPassiveDefense: raw['bonusPassiveDefense'],
      trainingLevel: raw['trainingLevel'],
      expeditionStart: raw['expeditionStart'] != null ? DateTime.parse(raw['expeditionStart']) : null,
      expeditionDurationHours: raw['expeditionDurationHours'],
    );
  }
}
