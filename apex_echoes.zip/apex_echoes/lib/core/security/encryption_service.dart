import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:encrypt/encrypt.dart' as encrypt;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Service de chiffrement AES-256 pour la sauvegarde locale.
///
/// Objectif : empêcher qu'un joueur modifie manuellement son fichier de
/// sauvegarde (Orins, stats, inventaire) même en accédant au stockage brut
/// de l'appareil. Une clé maître unique est générée à la première
/// installation et stockée dans le Keystore/Keychain sécurisé du téléphone.
class EncryptionService {
  static const _storage = FlutterSecureStorage();
  static const _keyStorageKey = 'apex_echoes_master_key';

  static Future<String> _getOrCreateMasterKey() async {
    String? key = await _storage.read(key: _keyStorageKey);
    if (key == null) {
      final newKey = encrypt.Key.fromSecureRandom(32).base64;
      await _storage.write(key: _keyStorageKey, value: newKey);
      key = newKey;
    }
    return key;
  }

  /// Chiffre une chaîne (le JSON complet de sauvegarde) et y ajoute une
  /// signature HMAC-SHA256 pour détecter toute altération manuelle.
  static Future<String> encryptData(String plainText) async {
    final keyString = await _getOrCreateMasterKey();
    final key = encrypt.Key.fromBase64(keyString);
    final iv = encrypt.IV.fromSecureRandom(16);

    final encrypter = encrypt.Encrypter(encrypt.AES(key, mode: encrypt.AESMode.cbc));
    final encrypted = encrypter.encrypt(plainText, iv: iv);

    final payload = {
      'iv': iv.base64,
      'data': encrypted.base64,
      'signature': _generateHMAC(encrypted.base64, keyString),
    };

    return jsonEncode(payload);
  }

  /// Déchiffre et vérifie l'intégrité. Renvoie `null` si les données ont été
  /// altérées ou sont corrompues (déclenche une réinitialisation côté appelant).
  static Future<String?> decryptData(String encryptedJson) async {
    try {
      final Map<String, dynamic> payload = jsonDecode(encryptedJson);
      final keyString = await _getOrCreateMasterKey();

      final expectedSignature = _generateHMAC(payload['data'], keyString);
      if (payload['signature'] != expectedSignature) {
        return null; // Tentative de modification détectée
      }

      final key = encrypt.Key.fromBase64(keyString);
      final iv = encrypt.IV.fromBase64(payload['iv']);
      final encrypter = encrypt.Encrypter(encrypt.AES(key, mode: encrypt.AESMode.cbc));
      final encrypted = encrypt.Encrypted.fromBase64(payload['data']);

      return encrypter.decrypt(encrypted, iv: iv);
    } catch (_) {
      return null;
    }
  }

  static String _generateHMAC(String data, String key) {
    final hmac = Hmac(sha256, utf8.encode(key));
    return hmac.convert(utf8.encode(data)).toString();
  }
}
