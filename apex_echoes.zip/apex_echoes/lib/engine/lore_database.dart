import '../models/lore_model.dart';

/// Base de données statique du lore du jeu : fragments d'histoire du monde
/// débloqués globalement, et fragments spécifiques à chaque espèce de
/// monstre, débloqués selon le nombre de victoires contre elle.
class LoreDatabase {
  /// Lore mondial, débloqué selon le nombre total de victoires cumulées
  /// (toutes espèces confondues) — trame façon "corruption du Gore Magala".
  static const List<LoreEntry> worldLore = [
    LoreEntry(
      title: "Les Premiers Échos",
      unlockThreshold: 1,
      content:
          "Les archives de la Guilde parlent d'un mal ancien, un virus "
          "capable de plonger n'importe quelle créature dans une frénésie "
          "violette. On l'appelle simplement : le Virus.",
    ),
    LoreEntry(
      title: "La Chaîne des Apex",
      unlockThreshold: 10,
      content:
          "Chaque petit monstre porte en lui l'écho génétique d'un Grand "
          "Boss. Les chasseurs qui élèvent leurs œufs jusqu'à maturité "
          "voient parfois resurgir des traits de leur ancêtre Apex.",
    ),
    LoreEntry(
      title: "Aura Violette",
      unlockThreshold: 25,
      content:
          "Un monstre infecté devient plus agressif et plus puissant, mais "
          "son organisme s'épuise plus vite qu'un spécimen sain. Certains "
          "chasseurs pensent que le Virus n'est qu'une étape d'évolution "
          "forcée, pas une maladie.",
    ),
    LoreEntry(
      title: "L'Origine du Virus",
      unlockThreshold: 50,
      content:
          "Un très ancien parchemin suggère que le Virus proviendrait d'un "
          "unique spécimen, un dragon primordial dont l'aura continuerait "
          "de contaminer les écosystèmes des siècles après sa disparition.",
    ),
  ];

  /// Fragments de lore spécifiques à une espèce, débloqués selon le nombre
  /// de victoires contre cette espèce précise.
  static const Map<String, List<LoreEntry>> monsterLore = {
    'Xero': [
      LoreEntry(
        title: "Xero, le Rôdeur des Glaces",
        unlockThreshold: 1,
        content: "Un prédateur agile qui chasse en petits groupes sur la banquise.",
      ),
      LoreEntry(
        title: "Comportement du Xero",
        unlockThreshold: 5,
        content: "Les Xero évitent le combat frontal et préfèrent épuiser leur proie.",
      ),
      LoreEntry(
        title: "Le Xero Ancestral",
        unlockThreshold: 15,
        content: "La légende parle d'un Xero si vieux qu'il aurait développé des écailles de dragon.",
      ),
    ],
    'Jagras': [
      LoreEntry(
        title: "Jagras, le Charognard",
        unlockThreshold: 1,
        content: "Une créature opportuniste qui suit les grands prédateurs pour se nourrir de leurs restes.",
      ),
      LoreEntry(
        title: "Meutes de Jagras",
        unlockThreshold: 5,
        content: "Isolé, le Jagras est inoffensif. En meute, il devient une menace sérieuse.",
      ),
    ],
    'Kirin': [
      LoreEntry(
        title: "Kirin, l'Esprit Foudroyant",
        unlockThreshold: 1,
        content: "Une créature électrique insaisissable, rarement observée directement.",
      ),
      LoreEntry(
        title: "Le Souverain Kirin",
        unlockThreshold: 10,
        content: "Certains chasseurs jurent avoir vu un Kirin diriger une tempête entière à volonté.",
      ),
    ],
    'Rune': [
      LoreEntry(
        title: "Rune, le Marqué",
        unlockThreshold: 1,
        content: "Des symboles anciens couvrent sa peau ; personne ne sait qui les y a gravés.",
      ),
    ],
    'Gore': [
      LoreEntry(
        title: "Gore, l'Infecté Originel",
        unlockThreshold: 1,
        content:
            "Le porteur le plus tristement célèbre du Virus. Sa forme corrompue "
            "diffuse une aura violette visible à des kilomètres.",
      ),
      LoreEntry(
        title: "Forme Brillante",
        unlockThreshold: 10,
        content:
            "Poussé à bout, Gore peut atteindre un état second où son aura "
            "devient éblouissante — un stade que peu de chasseurs ont survécu à observer.",
      ),
    ],
  };

  static List<LoreEntry> loreForMonster(String name) => monsterLore[name] ?? const [];
}
