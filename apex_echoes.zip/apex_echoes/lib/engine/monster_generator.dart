import 'dart:math';
import '../models/element_type.dart';
import '../models/monster_model.dart';
import '../models/zone_model.dart';

class MonsterGenerator {
  static final Random _rng = Random();
  static int _counter = 0;

  /// Instancie un [Monster] jouable à partir d'un slot d'expédition, mis à
  /// l'échelle selon le niveau de danger de la zone.
  static Monster generateFromSlot({
    required ExpeditionSlot slot,
    required Zone zone,
  }) {
    _counter++;
    final stage = slot.isBoss
        ? MonsterStage.apexBoss
        : MonsterStage.values[_rng.nextInt(2)]; // stage1 ou stage2

    final dangerScale = 1 + (zone.dangerLevel - 1) * 0.25;

    final baseMaxHp = slot.isBoss ? 150 : (stage == MonsterStage.stage1 ? 40 : 65);
    final baseAttack = slot.isBoss ? 18 : (stage == MonsterStage.stage1 ? 6 : 10);
    final baseDefense = slot.isBoss ? 8 : 3;

    // Taux de drop d'œuf : de 0.5% (petits monstres) à 7% (Grand Boss Apex).
    final eggDropRate = slot.isBoss ? 0.07 : 0.005;

    final weakness = _weaknessFor(zone.theme);

    return Monster(
      id: 'monster_${zone.id}_${_counter}_${DateTime.now().millisecondsSinceEpoch}',
      name: slot.monsterName,
      stage: stage,
      maxHp: (baseMaxHp * dangerScale).round(),
      attack: (baseAttack * dangerScale).round(),
      defense: (baseDefense * dangerScale).round(),
      element: zone.theme,
      weakness: weakness,
      isCorrupted: slot.willBeCorrupted,
      eggDropRate: eggDropRate,
    );
  }

  static ElementType _weaknessFor(ElementType theme) {
    switch (theme) {
      case ElementType.ice:
        return ElementType.fire;
      case ElementType.fire:
        return ElementType.thunder;
      case ElementType.thunder:
        return ElementType.dragon;
      case ElementType.dragon:
        return ElementType.ice;
      case ElementType.physical:
        return ElementType.physical;
    }
  }
}
