import 'dart:math';
import '../models/element_type.dart';
import '../models/equipment_model.dart';

/// Génération procédurale d'armes et d'armures à partir de préfixes/suffixes,
/// avec une rareté tirée aléatoirement (pondérée) et des stats mises à
/// l'échelle par la rareté.
class EquipmentGenerator {
  static final Random _rng = Random();
  static int _counter = 0;

  static const _prefixes = ['Dague', 'Lame', 'Bouclier', 'Heaume', 'Cuirasse', 'Griffe'];
  static const _materials = ['d\'ombre', 'de Runic', 'usé', 'ancestral', 'de givre', 'incandescent'];
  static const _suffixes = ['de l\'Infini', 'du Titan', 'de la Frénésie', 'des Abysses', 'Céleste'];

  /// Tire une rareté pondérée (le loot de haut rang est plus rare).
  static Rarity rollRarity({double luckBonus = 0.0}) {
    final roll = _rng.nextDouble() - luckBonus;
    if (roll < 0.45) return Rarity.common;
    if (roll < 0.70) return Rarity.rare;
    if (roll < 0.87) return Rarity.epic;
    if (roll < 0.96) return Rarity.legendary;
    if (roll < 0.99) return Rarity.mythic;
    return Rarity.cursed;
  }

  static Equipment generate({
    required EquipmentSlot slot,
    required ElementType element,
    Rarity? forcedRarity,
    double luckBonus = 0.0,
  }) {
    _counter++;
    final rarity = forcedRarity ?? rollRarity(luckBonus: luckBonus);

    final prefix = _prefixes[_rng.nextInt(_prefixes.length)];
    final material = _materials[_rng.nextInt(_materials.length)];
    final suffix = _suffixes[_rng.nextInt(_suffixes.length)];
    final name = '$prefix $material ${rarity == Rarity.mythic || rarity == Rarity.legendary ? suffix : ''}'.trim();

    final isWeapon = slot == EquipmentSlot.mainHand || slot == EquipmentSlot.offHand;
    final baseAttack = isWeapon ? 10 : 2;
    final baseDefense = isWeapon ? 1 : 6;

    return Equipment(
      id: 'equip_${_counter}_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      slot: slot,
      rarity: rarity,
      attackBonus: (baseAttack * rarity.statMultiplier).round(),
      defenseBonus: (baseDefense * rarity.statMultiplier).round(),
      elementType: isWeapon ? element : ElementType.physical,
      sharpnessMax: 20,
      currentSharpness: 20,
    );
  }
}
