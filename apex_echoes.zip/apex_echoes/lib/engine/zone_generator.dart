import 'dart:math';
import '../models/element_type.dart';
import '../models/zone_model.dart';

/// Générateur de zones et de rapports d'expédition.
///
/// Règles validées :
/// - 20 monstres au total par zone.
/// - Maximum 3 exemplaires identiques par nom pour les stades 1 et 2
///   (ex: seulement 3 "Xero" petits/moyens ; le reste doit être différent).
/// - 1 à 2 Grands Boss (Apex) par zone.
/// - 10% de chance globale qu'un monstre planifié soit corrompu (Aura Violette).
class ZoneGenerator {
  static final Random _rng = Random();

  static const int totalMonstersPerZone = 20;
  static const int maxIdenticalSpecimens = 3;
  static const double baseCorruptionChance = 0.10;

  static final List<Zone> availableZones = [
    Zone(
      id: 'zone_glacier',
      name: 'Crevasse Hurlante',
      theme: ElementType.ice,
      dangerLevel: 1,
      monsterPool: const ['Xero', 'Jagras', 'Kirin', 'Wyvern'],
      bossPool: const ['Shakuru'],
    ),
    Zone(
      id: 'zone_volcan',
      name: 'Caldeira Ardente',
      theme: ElementType.fire,
      dangerLevel: 2,
      monsterPool: const ['Gore', 'Rune', 'Jagras', 'Wyvern'],
      bossPool: const ['Gore Magala', 'Ombre Rathalos'],
    ),
    Zone(
      id: 'zone_ruines',
      name: 'Ruines Foudroyées',
      theme: ElementType.thunder,
      dangerLevel: 3,
      monsterPool: const ['Kirin', 'Rune', 'Xero', 'Gore'],
      bossPool: const ['Kirin Souverain'],
    ),
  ];

  /// Génère le rapport d'expédition consultable avant d'entrer dans la zone.
  static ExpeditionReport generateReport(Zone zone) {
    final slots = <ExpeditionSlot>[];
    final Map<String, int> stageCount = {};

    // 1 à 2 boss (Apex) par zone.
    final bossCount = 1 + _rng.nextInt(min(2, zone.bossPool.length));
    for (int i = 0; i < bossCount; i++) {
      final bossName = zone.bossPool[_rng.nextInt(zone.bossPool.length)];
      slots.add(ExpeditionSlot(
        monsterName: bossName,
        isBoss: true,
        willBeCorrupted: _rng.nextDouble() < baseCorruptionChance,
      ));
    }

    // Le reste des 20 emplacements est rempli avec des monstres normaux,
    // en respectant le cap de 3 exemplaires identiques par nom.
    final remainingSlots = totalMonstersPerZone - slots.length;
    for (int i = 0; i < remainingSlots; i++) {
      String candidate;
      int attempts = 0;
      do {
        candidate = zone.monsterPool[_rng.nextInt(zone.monsterPool.length)];
        attempts++;
      } while ((stageCount[candidate] ?? 0) >= maxIdenticalSpecimens && attempts < 30);

      stageCount[candidate] = (stageCount[candidate] ?? 0) + 1;
      slots.add(ExpeditionSlot(
        monsterName: candidate,
        isBoss: false,
        willBeCorrupted: _rng.nextDouble() < baseCorruptionChance,
      ));
    }

    return ExpeditionReport(
      zone: zone,
      plannedSlots: slots,
      corruptionChance: baseCorruptionChance,
    );
  }
}
