import 'dart:math';
import '../models/element_type.dart';
import '../models/monster_model.dart';
import '../models/player_model.dart';
import '../models/combat_log.dart';

/// Résultat d'une action de combat (utile pour piloter l'UI).
class CombatActionResult {
  final List<CombatLog> newLogs;
  final bool monsterDefeated;
  final bool playerDefeated;

  CombatActionResult({
    required this.newLogs,
    this.monsterDefeated = false,
    this.playerDefeated = false,
  });
}

class CombatEngine {
  static final Random _rng = Random();

  /// Matrice des faiblesses élémentaires (attaquant -> défenseur).
  static double getElementMultiplier(ElementType attacker, ElementType defender) {
    if (attacker == ElementType.physical) return 1.0;

    const superEffective = {
      ElementType.fire: ElementType.ice,
      ElementType.ice: ElementType.dragon,
      ElementType.thunder: ElementType.fire,
      ElementType.dragon: ElementType.thunder,
    };

    if (superEffective[attacker] == defender) return 1.5;
    if (attacker == defender) return 0.75; // Résistance au même élément
    return 1.0;
  }

  static int calculateDamage({
    required int rawAttack,
    required int rawDefense,
    required ElementType attackElement,
    required ElementType defenderWeakness,
    required bool isCritical,
    required double sharpnessMultiplier,
  }) {
    final baseDamage = (rawAttack - (rawDefense / 2)).clamp(1.0, 99999.0);
    final elemMult = getElementMultiplier(attackElement, defenderWeakness);
    final critMult = isCritical ? 1.5 : 1.0;

    final total = (baseDamage * elemMult * sharpnessMultiplier * critMult).round();
    return total.clamp(1, 999999);
  }

  static bool rollCritical({double baseChance = 0.20, double sharpnessBonus = 0.0}) {
    return _rng.nextDouble() < (baseChance + sharpnessBonus);
  }
}

/// Session de combat en tour par tour entre le joueur et un monstre.
class BattleSession {
  final Monster monster;
  final Player player;
  final List<CombatLog> logs = [];

  static const int staminaCostAttack = 5;
  static const int staminaCostSpecial = 15;

  BattleSession({required this.monster, required this.player});

  CombatActionResult attack() {
    final newLogs = <CombatLog>[];

    if (player.stamina < staminaCostAttack) {
      final log = CombatLog(
        "Vous êtes trop épuisé pour attaquer ! Reposez-vous un instant.",
        LogType.info,
      );
      logs.add(log);
      newLogs.add(log);
      return CombatActionResult(newLogs: newLogs);
    }
    player.stamina -= staminaCostAttack;

    final weapon = player.weapon;
    final sharpnessMult = weapon?.sharpnessDamageMultiplier ?? 1.0;
    if (weapon != null && weapon.currentSharpness > 0) {
      weapon.currentSharpness--;
    }

    final isCrit = CombatEngine.rollCritical(
      sharpnessBonus: (weapon != null && weapon.currentSharpness > 0) ? 0.03 : 0.0,
    );

    final damage = CombatEngine.calculateDamage(
      rawAttack: player.totalAttack,
      rawDefense: monster.defense,
      attackElement: player.weaponElement,
      defenderWeakness: monster.weakness,
      isCritical: isCrit,
      sharpnessMultiplier: sharpnessMult,
    );

    monster.hp -= damage;

    final critText = isCrit ? " [COUP CRITIQUE !]" : "";
    final atkLog = CombatLog(
      "Vous frappez le ${monster.name} et infligez $damage dégâts$critText.",
      LogType.playerAttack,
    );
    logs.add(atkLog);
    newLogs.add(atkLog);

    if (weapon != null && weapon.needsSharpening) {
      final log = CombatLog(
        "Votre arme est émoussée ! Pensez à l'aiguiser.",
        LogType.sharpness,
      );
      logs.add(log);
      newLogs.add(log);
    }

    if (monster.isDead) {
      monster.timesDefeated++;
      final log = CombatLog("🏆 Le ${monster.name} s'effondre ! Victoire !", LogType.reward);
      logs.add(log);
      newLogs.add(log);
      return CombatActionResult(newLogs: newLogs, monsterDefeated: true);
    }

    return _monsterRiposte(newLogs);
  }

  CombatActionResult sharpenWeapon() {
    final newLogs = <CombatLog>[];
    final weapon = player.weapon;
    if (weapon == null) {
      final log = CombatLog("Vous n'avez aucune arme équipée à aiguiser.", LogType.info);
      logs.add(log);
      newLogs.add(log);
      return CombatActionResult(newLogs: newLogs);
    }

    weapon.currentSharpness = weapon.sharpnessMax;
    final log = CombatLog(
      "⚔️ Vous aiguisez votre lame. Tranchant restauré (+3% dégâts/crit) !",
      LogType.sharpness,
    );
    logs.add(log);
    newLogs.add(log);

    // Le monstre profite de ce tour pour attaquer.
    return _monsterRiposte(newLogs);
  }

  CombatActionResult rest() {
    final newLogs = <CombatLog>[];
    player.stamina = (player.stamina + 20).clamp(0, player.maxStamina);
    final log = CombatLog("Vous reprenez votre souffle (+20 Endurance).", LogType.info);
    logs.add(log);
    newLogs.add(log);
    return _monsterRiposte(newLogs);
  }

  CombatActionResult _monsterRiposte(List<CombatLog> newLogs) {
    final damage = (monster.currentAttack - (player.totalDefense / 2))
        .round()
        .clamp(1, 999999);
    player.hp -= damage;

    final corruptedText = monster.isCorrupted ? " [Aura Violette]" : "";
    final log = CombatLog(
      "Le ${monster.name}$corruptedText riposte et inflige $damage dégâts !",
      LogType.monsterAttack,
    );
    logs.add(log);
    newLogs.add(log);

    if (player.hp <= 0) {
      final defeatLog = CombatLog("💀 Vous avez été terrassé...", LogType.danger);
      logs.add(defeatLog);
      newLogs.add(defeatLog);
      return CombatActionResult(newLogs: newLogs, playerDefeated: true);
    }

    return CombatActionResult(newLogs: newLogs);
  }
}
