import 'element_type.dart';
import 'equipment_model.dart';

class Player {
  int hp;
  int maxHp;
  int stamina;
  int maxStamina;
  int baseAttack;
  int baseDefense;
  int orins; // Monnaie du jeu

  // Équipement porté par emplacement
  Map<EquipmentSlot, Equipment?> equippedItems;

  Player({
    this.hp = 100,
    this.maxHp = 100,
    this.stamina = 50,
    this.maxStamina = 50,
    this.baseAttack = 15,
    this.baseDefense = 5,
    this.orins = 50,
    Map<EquipmentSlot, Equipment?>? equippedItems,
  }) : equippedItems = equippedItems ??
            {
              for (final slot in EquipmentSlot.values) slot: null,
            };

  Equipment? get weapon => equippedItems[EquipmentSlot.mainHand];

  int get totalAttack =>
      baseAttack + equippedItems.values.fold(0, (sum, e) => sum + (e?.attackBonus ?? 0));

  int get totalDefense =>
      baseDefense + equippedItems.values.fold(0, (sum, e) => sum + (e?.defenseBonus ?? 0));

  ElementType get weaponElement => weapon?.elementType ?? ElementType.physical;

  Map<String, dynamic> toJson() => {
        'hp': hp,
        'maxHp': maxHp,
        'stamina': stamina,
        'maxStamina': maxStamina,
        'baseAttack': baseAttack,
        'baseDefense': baseDefense,
        'orins': orins,
        'equippedItems': equippedItems.map(
          (slot, eq) => MapEntry(slot.index.toString(), eq?.toJson()),
        ),
      };

  factory Player.fromJson(Map<String, dynamic> json) {
    final equipped = <EquipmentSlot, Equipment?>{};
    final rawEquipped = json['equippedItems'] as Map<String, dynamic>? ?? {};
    for (final slot in EquipmentSlot.values) {
      final raw = rawEquipped[slot.index.toString()];
      equipped[slot] = raw != null ? Equipment.fromJson(raw) : null;
    }
    return Player(
      hp: json['hp'],
      maxHp: json['maxHp'],
      stamina: json['stamina'],
      maxStamina: json['maxStamina'],
      baseAttack: json['baseAttack'],
      baseDefense: json['baseDefense'],
      orins: json['orins'],
      equippedItems: equipped,
    );
  }
}
