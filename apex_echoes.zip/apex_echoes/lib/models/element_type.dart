/// Types élémentaires utilisés par les monstres, armes et armures.
enum ElementType { physical, fire, ice, thunder, dragon }

extension ElementTypeLabel on ElementType {
  String get label {
    switch (this) {
      case ElementType.physical:
        return 'Physique';
      case ElementType.fire:
        return 'Feu';
      case ElementType.ice:
        return 'Glace';
      case ElementType.thunder:
        return 'Foudre';
      case ElementType.dragon:
        return 'Dragon';
    }
  }

  String get icon {
    switch (this) {
      case ElementType.physical:
        return '⚔️';
      case ElementType.fire:
        return '🔥';
      case ElementType.ice:
        return '❄️';
      case ElementType.thunder:
        return '⚡';
      case ElementType.dragon:
        return '🐉';
    }
  }
}
