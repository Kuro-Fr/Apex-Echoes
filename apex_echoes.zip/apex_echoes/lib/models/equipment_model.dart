import 'element_type.dart';

/// Rareté d'un équipement, du plus commun au plus rare.
enum Rarity { common, rare, epic, legendary, mythic, cursed }

extension RarityLabel on Rarity {
  String get label {
    switch (this) {
      case Rarity.common:
        return 'Commun';
      case Rarity.rare:
        return 'Rare';
      case Rarity.epic:
        return 'Épique';
      case Rarity.legendary:
        return 'Légendaire';
      case Rarity.mythic:
        return 'Mythique';
      case Rarity.cursed:
        return 'Maudit';
    }
  }

  /// Multiplicateur de stats appliqué selon la rareté.
  double get statMultiplier {
    switch (this) {
      case Rarity.common:
        return 1.0;
      case Rarity.rare:
        return 1.2;
      case Rarity.epic:
        return 1.45;
      case Rarity.legendary:
        return 1.8;
      case Rarity.mythic:
        return 2.3;
      case Rarity.cursed:
        return 2.6; // Très puissant mais avec un malus caché (ex : -PV max)
    }
  }
}

enum EquipmentSlot { head, chest, legs, mainHand, offHand, perk1, perk2, petPerk }

extension EquipmentSlotLabel on EquipmentSlot {
  String get label {
    switch (this) {
      case EquipmentSlot.head:
        return 'Tête';
      case EquipmentSlot.chest:
        return 'Torse';
      case EquipmentSlot.legs:
        return 'Jambes';
      case EquipmentSlot.mainHand:
        return 'Arme Principale';
      case EquipmentSlot.offHand:
        return 'Arme Secondaire';
      case EquipmentSlot.perk1:
        return 'Atout I';
      case EquipmentSlot.perk2:
        return 'Atout II';
      case EquipmentSlot.petPerk:
        return 'Atout Compagnon';
    }
  }
}

class Equipment {
  final String id;
  final String name; // Généré procéduralement : "Dague d'ombre de l'Infini"
  final EquipmentSlot slot;
  final Rarity rarity;
  final int attackBonus;
  final int defenseBonus;
  final ElementType elementType;

  // Tranchant (uniquement pertinent pour l'arme principale)
  int sharpnessMax;
  int currentSharpness;

  Equipment({
    required this.id,
    required this.name,
    required this.slot,
    required this.rarity,
    this.attackBonus = 0,
    this.defenseBonus = 0,
    this.elementType = ElementType.physical,
    this.sharpnessMax = 20,
    this.currentSharpness = 20,
  });

  bool get needsSharpening => slot == EquipmentSlot.mainHand && currentSharpness <= 0;

  /// Bonus de dégâts/critique quand l'arme est bien aiguisée (+3%).
  double get sharpnessDamageMultiplier {
    if (slot != EquipmentSlot.mainHand) return 1.0;
    return currentSharpness > 0 ? 1.03 : 0.90;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'slot': slot.index,
        'rarity': rarity.index,
        'attackBonus': attackBonus,
        'defenseBonus': defenseBonus,
        'elementType': elementType.index,
        'sharpnessMax': sharpnessMax,
        'currentSharpness': currentSharpness,
      };

  factory Equipment.fromJson(Map<String, dynamic> json) => Equipment(
        id: json['id'],
        name: json['name'],
        slot: EquipmentSlot.values[json['slot']],
        rarity: Rarity.values[json['rarity']],
        attackBonus: json['attackBonus'],
        defenseBonus: json['defenseBonus'],
        elementType: ElementType.values[json['elementType']],
        sharpnessMax: json['sharpnessMax'],
        currentSharpness: json['currentSharpness'],
      );
}
