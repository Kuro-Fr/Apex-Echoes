import 'monster_model.dart';

/// Compagnon issu d'un œuf (mécanique "Tamagotchi").
/// Chaque petit monstre est une sous-évolution du Grand Boss (Apex) dont il descend.
class CompanionPet {
  final String id;
  final String speciesName; // Ex: "Xero"
  final String originApexBossId; // Boss dont provient l'œuf
  MonsterStage currentStage;

  // Statistiques de type Tamagotchi (0 à 100)
  int hungerLevel;
  int hygieneLevel;
  int affectionLevel;

  final DateTime hatchDate;

  /// Nombre de jours réels nécessaires à la maturation complète (ex: 15 jours
  /// pour un compagnon issu d'un boss très difficile). Réductible par les soins.
  final int growthDaysRequired;

  /// Jours de maturation déjà accumulés (peut avancer plus vite si bien soigné).
  double growthDaysAccumulated;

  // Bonus passifs donnés au joueur en tant que 3e Atout
  int bonusPassiveAttack;
  int bonusPassiveDefense;

  // Statistiques d'entraînement (chasse / expéditions AFK)
  int trainingLevel;

  /// Expédition en arrière-plan (le compagnon part chasser seul pendant que
  /// le joueur fait autre chose, ou même quand l'application est fermée :
  /// le calcul se fait toujours sur la différence de temps réel écoulé entre
  /// le début de l'expédition et le moment où le joueur revient consulter le
  /// résultat, donc aucun service natif en arrière-plan n'est nécessaire).
  DateTime? expeditionStart;
  int? expeditionDurationHours;

  CompanionPet({
    required this.id,
    required this.speciesName,
    required this.originApexBossId,
    this.currentStage = MonsterStage.stage1,
    this.hungerLevel = 100,
    this.hygieneLevel = 100,
    this.affectionLevel = 50,
    required this.hatchDate,
    required this.growthDaysRequired,
    this.growthDaysAccumulated = 0,
    this.bonusPassiveAttack = 5,
    this.bonusPassiveDefense = 5,
    this.trainingLevel = 0,
    this.expeditionStart,
    this.expeditionDurationHours,
  });

  bool get isFullyGrown => growthDaysAccumulated >= growthDaysRequired;

  double get growthProgress =>
      (growthDaysAccumulated / growthDaysRequired).clamp(0.0, 1.0);

  /// Nourrir le compagnon : augmente la faim et accélère légèrement la croissance.
  void feed() {
    hungerLevel = (hungerLevel + 25).clamp(0, 100);
    growthDaysAccumulated += 0.15;
  }

  /// Donner un bain : augmente l'hygiène et l'affection.
  void bathe() {
    hygieneLevel = (hygieneLevel + 30).clamp(0, 100);
    affectionLevel = (affectionLevel + 5).clamp(0, 100);
  }

  /// Entraîner le compagnon : augmente légèrement ses stats passives et son
  /// niveau pour les combats AFK, mais consomme un peu de faim/hygiène.
  void train() {
    trainingLevel++;
    bonusPassiveAttack += 1;
    bonusPassiveDefense += 1;
    hungerLevel = (hungerLevel - 10).clamp(0, 100);
    hygieneLevel = (hygieneLevel - 5).clamp(0, 100);
    growthDaysAccumulated += 0.1;
  }

  /// Avance la maturation en fonction du temps réel écoulé, modulé par les
  /// soins reçus (faim/hygiène élevées = croissance normale, sinon ralentie).
  void tickDailyGrowth() {
    final careFactor = ((hungerLevel + hygieneLevel) / 200).clamp(0.3, 1.2);
    growthDaysAccumulated += careFactor;
    if (isFullyGrown && currentStage != MonsterStage.apexBoss) {
      currentStage = currentStage == MonsterStage.stage1
          ? MonsterStage.stage2
          : MonsterStage.apexBoss;
    }
  }

  bool get isOnExpedition => expeditionStart != null && expeditionDurationHours != null;

  /// Temps déjà écoulé depuis le départ en expédition, plafonné à la durée prévue.
  Duration get expeditionElapsed {
    if (!isOnExpedition) return Duration.zero;
    final elapsed = DateTime.now().difference(expeditionStart!);
    final maxDuration = Duration(hours: expeditionDurationHours!);
    return elapsed > maxDuration ? maxDuration : elapsed;
  }

  bool get isExpeditionReady {
    if (!isOnExpedition) return false;
    return DateTime.now().difference(expeditionStart!) >=
        Duration(hours: expeditionDurationHours!);
  }

  double get expeditionProgress {
    if (!isOnExpedition) return 0;
    return expeditionElapsed.inMinutes / (expeditionDurationHours! * 60);
  }

  /// Envoie le compagnon chasser seul pendant [hours] heures. Fonctionne même
  /// si l'application est fermée entre-temps : le calcul se base uniquement
  /// sur l'horodatage réel, comparé à nouveau à l'ouverture de l'application.
  void startExpedition(int hours) {
    expeditionStart = DateTime.now();
    expeditionDurationHours = hours;
  }

  /// Calcule et renvoie le butin d'expédition (Orins), puis libère le
  /// compagnon. À appeler uniquement quand [isOnExpedition] est vrai.
  int collectExpeditionReward() {
    final stageFactor = switch (currentStage) {
      MonsterStage.stage1 => 1.0,
      MonsterStage.stage2 => 1.5,
      MonsterStage.apexBoss => 2.2,
    };
    final orinsPerHour = (4 + trainingLevel * 1.5) * stageFactor;
    final hoursCompleted = expeditionElapsed.inMinutes / 60;
    final reward = (orinsPerHour * hoursCompleted).round();

    growthDaysAccumulated += hoursCompleted / 24; // La chasse fait aussi grandir le compagnon
    hungerLevel = (hungerLevel - (hoursCompleted * 2).round()).clamp(0, 100);

    expeditionStart = null;
    expeditionDurationHours = null;
    return reward;
  }
}
