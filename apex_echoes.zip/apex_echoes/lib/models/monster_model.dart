import 'element_type.dart';

enum MonsterStage { stage1, stage2, apexBoss }

extension MonsterStageLabel on MonsterStage {
  String get label {
    switch (this) {
      case MonsterStage.stage1:
        return 'Petit';
      case MonsterStage.stage2:
        return 'Moyen';
      case MonsterStage.apexBoss:
        return 'Apex (Grand Boss)';
    }
  }
}

class Monster {
  final String id;
  final String name;
  final MonsterStage stage;
  final int maxHp;
  int hp;
  final int attack;
  final int defense;
  final ElementType element;
  final ElementType weakness;

  /// Frénésie / Aura Violette : le monstre est corrompu par le virus.
  final bool isCorrupted;

  /// Taux de drop de l'œuf du compagnon (0.005 = 0.5% ... 0.07 = 7%).
  final double eggDropRate;

  /// Nombre de fois où ce monstre a été vaincu (débloque du lore).
  int timesDefeated;

  Monster({
    required this.id,
    required this.name,
    required this.stage,
    required this.maxHp,
    required this.attack,
    required this.defense,
    required this.element,
    required this.weakness,
    this.isCorrupted = false,
    required this.eggDropRate,
    int? hp,
    this.timesDefeated = 0,
  }) : hp = hp ?? maxHp;

  /// Multiplicateur "Raid" quand le monstre est corrompu (style Frénésie / Aura Violette).
  int get currentAttack => isCorrupted ? (attack * 1.35).round() : attack;
  int get currentMaxHp => isCorrupted ? (maxHp * 1.5).round() : maxHp;

  bool get isDead => hp <= 0;
}
