/// Fragment de lore (Codex) débloqué progressivement.
class LoreEntry {
  final String title;
  final String content;

  /// Nombre de victoires nécessaires contre le monstre concerné (ou
  /// jalon global) pour débloquer ce fragment.
  final int unlockThreshold;

  const LoreEntry({
    required this.title,
    required this.content,
    required this.unlockThreshold,
  });
}
