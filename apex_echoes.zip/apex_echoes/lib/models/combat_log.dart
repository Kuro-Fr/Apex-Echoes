enum LogType { info, playerAttack, monsterAttack, status, sharpness, reward, danger }

class CombatLog {
  final String message;
  final LogType type;
  final DateTime timestamp;

  CombatLog(this.message, this.type) : timestamp = DateTime.now();
}
