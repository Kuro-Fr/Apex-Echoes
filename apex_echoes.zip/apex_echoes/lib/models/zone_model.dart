import 'element_type.dart';

/// Une zone de chasse (façon Monster Hunter) avec son thème élémentaire et
/// son niveau de danger. Le joueur peut entrer/quitter la zone à tout moment.
class Zone {
  final String id;
  final String name;
  final ElementType theme;
  final int dangerLevel; // Influence les stats des monstres et la rareté du loot

  /// Liste des noms de base de monstres pouvant apparaître dans cette zone.
  final List<String> monsterPool;

  /// Nom(s) du/des Grand(s) Boss (Apex) de la zone (1 ou 2 maximum).
  final List<String> bossPool;

  const Zone({
    required this.id,
    required this.name,
    required this.theme,
    required this.dangerLevel,
    required this.monsterPool,
    required this.bossPool,
  });
}

/// Un slot de monstre planifié dans le rapport d'expédition, avant d'entrer
/// réellement dans la zone.
class ExpeditionSlot {
  final String monsterName;
  final bool isBoss;
  final bool willBeCorrupted;

  ExpeditionSlot({
    required this.monsterName,
    required this.isBoss,
    required this.willBeCorrupted,
  });
}

/// Rapport d'expédition consultable avant d'entrer dans une zone : il liste
/// les monstres présents et le pourcentage de chance de tomber sur une
/// créature corrompue par le virus (Aura Violette).
class ExpeditionReport {
  final Zone zone;
  final List<ExpeditionSlot> plannedSlots;
  final double corruptionChance; // Ex: 0.10 = 10%

  ExpeditionReport({
    required this.zone,
    required this.plannedSlots,
    required this.corruptionChance,
  });
}
