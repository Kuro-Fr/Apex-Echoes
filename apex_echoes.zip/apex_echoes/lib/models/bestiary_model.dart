import 'element_type.dart';
import 'monster_model.dart';

/// Fiche de bestiaire pour une espèce de monstre rencontrée. Contient un
/// instantané de ses statistiques ainsi que le nombre de fois où elle a été
/// vaincue (ce compteur déverrouille progressivement des fragments de lore).
class BestiaryEntry {
  final String name;
  final MonsterStage lastSeenStage;
  final ElementType element;
  final ElementType weakness;
  final double eggDropRate;
  int timesDefeated;

  BestiaryEntry({
    required this.name,
    required this.lastSeenStage,
    required this.element,
    required this.weakness,
    required this.eggDropRate,
    this.timesDefeated = 0,
  });

  factory BestiaryEntry.fromMonster(Monster monster) => BestiaryEntry(
        name: monster.name,
        lastSeenStage: monster.stage,
        element: monster.element,
        weakness: monster.weakness,
        eggDropRate: monster.eggDropRate,
        timesDefeated: 1,
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'lastSeenStage': lastSeenStage.index,
        'element': element.index,
        'weakness': weakness.index,
        'eggDropRate': eggDropRate,
        'timesDefeated': timesDefeated,
      };

  factory BestiaryEntry.fromJson(Map<String, dynamic> json) => BestiaryEntry(
        name: json['name'],
        lastSeenStage: MonsterStage.values[json['lastSeenStage']],
        element: ElementType.values[json['element']],
        weakness: ElementType.values[json['weakness']],
        eggDropRate: (json['eggDropRate'] as num).toDouble(),
        timesDefeated: json['timesDefeated'],
      );
}
